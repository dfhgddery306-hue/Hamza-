# Hamza TV

واجهة ويب عربية متجاوبة لتشغيل روابط HLS (`.m3u8`) التي تملك حق بثها أو إعادة توزيعها.

## تجهيز القنوات
عدّل `data/channels.json` وأضف روابط البث المرخصة لك. احذف القناة التجريبية قبل النشر:
```json
[
  {"id":"channel-1","name":"اسم القناة","category":"أخبار","logo":"","url":"https://example.com/authorized-stream.m3u8"}
]
```
لا تضع بيانات حساب مزود IPTV أو كلمات المرور في HTML أو JavaScript.

## التثبيت والتشغيل على Ubuntu VPS
ارفع المجلد إلى الخادم ثم:
```bash
cd Hamza-TV
chmod +x *.sh
./install.sh
./run.sh
```
اختبر:
```bash
curl -I http://127.0.0.1:8080
tail -f hamza-tv.log
```
إيقاف/إعادة تشغيل:
```bash
./stop.sh
./restart.sh
```
هذا التشغيل مناسب للخوادم/الحاويات التي لا يعمل فيها systemd. قد تحتاج إلى إعادة تشغيل `./run.sh` بعد إعادة تشغيل الحاوية أو الخادم.

## إتاحة الموقع للأصدقاء عبر Nginx
عدّل `deploy/nginx-hamza-tv.conf` واستبدل `YOUR_DOMAIN_OR_SERVER_IP` بالدومين أو IP، ثم:
```bash
cp deploy/nginx-hamza-tv.conf /etc/nginx/sites-available/hamza-tv
ln -s /etc/nginx/sites-available/hamza-tv /etc/nginx/sites-enabled/hamza-tv
nginx -t
nginx
# إذا كان Nginx يعمل بالفعل:
nginx -s reload
```
تأكد أن DNS يشير إلى IP الخادم وأن منافذ 80 و443 مفتوحة في لوحة VPS والجدار الناري.

## HTTPS بدومين
بعد ربط دومين تملكه وفتح المنفذ 80:
```bash
apt-get install -y certbot python3-certbot-nginx
certbot --nginx -d YOUR_DOMAIN
```
اتبع التعليمات. لا يمكن إصدار شهادة موثوقة عادةً لعنوان IP عادي؛ استخدم دومينًا تملكه.

## ملاحظات مهمة
- المشروع لا يتصل تلقائيًا بمزود IPTV ولا يتجاوز الحماية أو القيود.
- أضف فقط روابط البث التي تملكها أو لديك إذن صريح لإعادة توزيعها.
- في هذا الإصدار المتصفح يتصل بمصدر HLS مباشرة؛ قد يمنع المصدر التشغيل بسبب CORS أو تقييد النطاق أو انتهاء صلاحية الرابط.
- مشاهدة الأصدقاء تستهلك الإنترنت من مصدر البث مباشرة، وليست عبر VPS في هذا الإصدار.
- ملف Nginx موجود في `deploy/nginx-hamza-tv.conf`.
