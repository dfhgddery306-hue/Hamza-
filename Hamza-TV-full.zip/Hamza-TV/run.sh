#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$APP_DIR/hamza-tv.pid"
LOGFILE="$APP_DIR/hamza-tv.log"
if [ ! -x "$APP_DIR/.venv/bin/gunicorn" ]; then
  echo "ثبّت المتطلبات أولاً عبر ./install.sh"; exit 1
fi
if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "الموقع يعمل بالفعل، PID: $(cat "$PIDFILE")"; exit 0
fi
cd "$APP_DIR"
nohup "$APP_DIR/.venv/bin/gunicorn" --workers 2 --bind 127.0.0.1:8080 --timeout 120 app:app >> "$LOGFILE" 2>&1 &
echo $! > "$PIDFILE"
sleep 2
if kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "Hamza TV يعمل على http://127.0.0.1:8080"
  echo "السجل: $LOGFILE"
else
  echo "فشل التشغيل. راجع السجل: $LOGFILE"; exit 1
fi
