
# -*- coding: utf-8 -*-

import json
import os
from pathlib import Path

from flask import Flask, render_template, jsonify

# =====================================
# Hamza TV Configuration
# =====================================

ROOT = Path(__file__).resolve().parent

CHANNELS_FILE = Path(
    os.getenv("CHANNELS_FILE", str(ROOT / "data" / "channels.json"))
)

SITE_NAME = os.getenv("SITE_NAME", "Hamza TV")

HOST = "0.0.0.0"
PORT = int(os.getenv("PORT", "8080"))

app = Flask(__name__)


# =====================================
# Load Channels
# =====================================

def load_channels():
    try:
        if not CHANNELS_FILE.exists():
            return []

        data = json.loads(
            CHANNELS_FILE.read_text(encoding="utf-8")
        )

        if not isinstance(data, list):
            return []

        channels = []

        for i, ch in enumerate(data):
            if not isinstance(ch, dict):
                continue

            url = str(ch.get("url", "")).strip()

            # Accept only HTTP/HTTPS stream URLs
            if not url.startswith(("https://", "http://")):
                continue

            channels.append({
                "id": str(ch.get("id", i)),
                "name": str(ch.get("name", "قناة")),
                "category": str(ch.get("category", "عام")),
                "logo": str(ch.get("logo", "")),
                "url": url,
            })

        return channels

    except (OSError, json.JSONDecodeError) as error:
        app.logger.error("Channels loading error: %s", error)
        return []


# =====================================
# Home Page
# =====================================

@app.get("/")
def index():
    return render_template(
        "index.html",
        site_name=SITE_NAME
    )


# =====================================
# Channels API
# =====================================

@app.get("/api/channels")
def api_channels():
    response = jsonify(load_channels())
    response.headers["Cache-Control"] = "no-store"
    return response


# =====================================
# Health Check
# =====================================

@app.get("/health")
def health():
    return jsonify({
        "status": "ok",
        "site": SITE_NAME
    })


# =====================================
# Error Handling
# =====================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Page not found"
    }), 404


@app.errorhandler(500)
def server_error(error):
    app.logger.exception("Internal server error")
    return jsonify({
        "error": "Internal server error"
    }), 500


# =====================================
# Start Application
# =====================================

if __name__ == "__main__":
    app.run(
        host=HOST,
        port=PORT,
        debug=False,
        threaded=True
    )
