#!/usr/bin/env bash
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
"$APP_DIR/stop.sh" || true
sleep 1
"$APP_DIR/run.sh"
