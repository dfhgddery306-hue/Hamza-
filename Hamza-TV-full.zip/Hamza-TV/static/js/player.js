const video = document.getElementById("video");
const list = document.getElementById("channels");
const categoriesBox = document.getElementById("categories");
const search = document.getElementById("search");
const empty = document.getElementById("empty");
const statusEl = document.getElementById("status");
let allChannels = [], selectedCategory = "الكل", activeId = null, hls = null;

function setStatus(text, live=false) {
  statusEl.textContent = text;
  statusEl.classList.toggle("live", live);
}
function stopPlayer() {
  if (hls) { hls.destroy(); hls = null; }
  video.pause(); video.removeAttribute("src"); video.load();
}
function playChannel(ch) {
  if (!ch || !ch.url) return;
  stopPlayer(); activeId = ch.id; empty.style.display = "none";
  document.getElementById("currentName").textContent = ch.name;
  document.getElementById("currentCategory").textContent = ch.category;
  setStatus("جارٍ الاتصال...");
  renderChannels();
  if (window.Hls && Hls.isSupported()) {
    hls = new Hls({enableWorker:true});
    hls.loadSource(ch.url); hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      setStatus("يعمل الآن", true);
      video.play().catch(() => setStatus("اضغط تشغيل لبدء المشاهدة"));
    });
    hls.on(Hls.Events.ERROR, (_event, data) => {
      if (data.fatal) setStatus("تعذر تشغيل القناة");
    });
  } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
    video.src = ch.url;
    video.addEventListener("loadedmetadata", () => {
      setStatus("يعمل الآن", true);
      video.play().catch(() => setStatus("اضغط تشغيل لبدء المشاهدة"));
    }, {once:true});
    video.addEventListener("error", () => setStatus("تعذر تشغيل القناة"), {once:true});
  } else setStatus("المتصفح لا يدعم HLS");
}
function renderCategories() {
  const cats = ["الكل", ...new Set(allChannels.map(c => c.category || "عام"))];
  categoriesBox.innerHTML = "";
  cats.forEach(cat => {
    const b = document.createElement("button");
    b.className = "category" + (cat === selectedCategory ? " active" : "");
    b.textContent = cat;
    b.onclick = () => { selectedCategory = cat; renderCategories(); renderChannels(); };
    categoriesBox.appendChild(b);
  });
}
function renderChannels() {
  const q = search.value.trim().toLowerCase();
  const filtered = allChannels.filter(c =>
    (selectedCategory === "الكل" || c.category === selectedCategory) &&
    c.name.toLowerCase().includes(q)
  );
  list.innerHTML = "";
  if (!filtered.length) { list.innerHTML = '<p class="muted">لا توجد قنوات مطابقة.</p>'; return; }
  filtered.forEach(ch => {
    const b = document.createElement("button");
    b.className = "channel" + (ch.id === activeId ? " active" : "");
    if (ch.logo) {
      const img = document.createElement("img"); img.src = ch.logo; img.alt = ""; img.loading = "lazy";
      b.appendChild(img);
    } else {
      const logo = document.createElement("span"); logo.className = "logo-placeholder"; logo.textContent = "📺"; b.appendChild(logo);
    }
    const label = document.createElement("span");
    label.innerHTML = "";
    const name = document.createElement("span"); name.className = "name"; name.textContent = ch.name;
    const cat = document.createElement("span"); cat.className = "cat"; cat.textContent = ch.category;
    label.append(name, cat); b.appendChild(label);
    b.onclick = () => playChannel(ch);
    list.appendChild(b);
  });
}
async function init() {
  try {
    const response = await fetch("/api/channels");
    if (!response.ok) throw new Error("HTTP " + response.status);
    allChannels = await response.json();
    renderCategories(); renderChannels();
    if (!allChannels.length) list.innerHTML = '<p class="muted">أضف روابط القنوات المصرح لك ببثها في data/channels.json</p>';
  } catch (e) {
    list.innerHTML = '<p class="muted">تعذر تحميل قائمة القنوات.</p>';
    setStatus("خطأ في تحميل القنوات");
  }
}
search.addEventListener("input", renderChannels);
init();
