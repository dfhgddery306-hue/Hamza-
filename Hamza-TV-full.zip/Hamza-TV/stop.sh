#!/usr/bin/env bash
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$APP_DIR/hamza-tv.pid"
if [ -f "$PIDFILE" ]; then
  PID="$(cat "$PIDFILE")"
  if kill -0 "$PID" 2>/dev/null; then kill "$PID"; echo "تم إيقاف Hamza TV (PID $PID)"; else echo "العملية غير موجودة"; fi
  rm -f "$PIDFILE"
else
  echo "لا يوجد ملف PID؛ هل الموقع يعمل؟"
fi
