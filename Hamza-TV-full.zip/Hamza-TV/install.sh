#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ "$(id -u)" -ne 0 ]; then
  echo "شغّل السكربت بصلاحية root: sudo ./install.sh"
  exit 1
fi
apt-get update
apt-get install -y python3 python3-venv python3-pip nginx
python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
chmod +x "$APP_DIR/run.sh" "$APP_DIR/stop.sh"
echo "اكتمل التثبيت. شغّل الموقع بالأمر: ./run.sh"
